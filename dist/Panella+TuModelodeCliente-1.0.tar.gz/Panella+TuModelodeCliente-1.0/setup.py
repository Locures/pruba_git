from setuptools import setup 

setup(
    name="Panella+TuModelodeCliente",
    version="1.0",
    author="Guido Panella",
    author_email="gpanella6@gmail.com",
    description= "Es la segunda pre-entrega",
    packages=["segunda_entrega"]
)