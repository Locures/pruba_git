from modulo_1 import Cliente
#modulo para ejcutar, se incluye ejemplos
cliente1 = Cliente("Juan", 17, "CABA", 2000)

#cliente1.cliente_mayor()

print(cliente1)